﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Aula12;

namespace Teste
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Aluno a1 = new Aluno();
            a1.Nome = "Felipe";
            a1.Sobrenome = "Vozgeral Çanca";
            a1.DataNascimento = new DateTime(1990, 04, 01);

            Aluno a2 = new Aluno();
            a2.Nome = "Alin@";
            a2.Sobrenome = "Branca";
            a2.DataNascimento = new DateTime(2020, 01, 01);

            Aluno a3 = new Aluno();
            a3.Nome = "Alfredo";
            a3.Sobrenome = "Sella III";
            a3.DataNascimento = new DateTime(1986, 03, 12);
        }
    }
}
