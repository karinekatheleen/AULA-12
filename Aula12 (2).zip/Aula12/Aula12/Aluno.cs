﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula12
{
    public class Aluno
    {
        public int codigo { get; set; }
        public string Nome { get; set; }
        public string Sobrenome { get; set; }
        public DateTime DataNascimento { get; set; }

        public DateTime Data;

        public int Idade()
        {
            var b = DateTime.Now;
            Data = b;
            var i = Convert.ToInt32(Data.Year - DataNascimento.Year);
            return i;
        }

        public string NomeCompleto()
        {
            return string.Concat(Nome + Sobrenome);
        }

        public int ValidacaoNome()
        {
            int i = 0;
            string n = Nome;
            string s = Sobrenome;

            if (n.Contains(" Ç") || n.Contains(" ç") || s.Contains(" Ç") || s.Contains(" ç"))
            {
                Console.WriteLine("Este nome é não pode ser utilizado. Contém caracter 'Ç' que é inválido no início");
                i = +1;
            }
            if (n.Contains("@") || s.Contains("@"))
            {
                Console.WriteLine("Este nome não podeser utilizado. Contém caracter '@' que é inválido");
                i = +2;
            }
            return i;
        }

        public string ValidaErro(int i)
        {
            string m;
            if (ValidacaoNome() == 1)
            {
                m = "Erro devido ao 'Ç'";
                return m;
            }
            else if (ValidacaoNome() == 2)
            {
                m = "Erro devido ao '@'";
                return m;
            }

            return " ";
        }
    }
}

  
